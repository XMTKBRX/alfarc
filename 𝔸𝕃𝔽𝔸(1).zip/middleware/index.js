import { commandMiddleware } from "./commands.middleware.js";
import { eventMiddleware } from "./event.middleware.js"; 

export {
    commandMiddleware,
    eventMiddleware
}