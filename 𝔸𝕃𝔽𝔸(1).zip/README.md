<p align="center">
<img src="https://i.ibb.co/74m2BvB/Picsart-24-08-20-12-21-07-698.jpg"/>
</p>
<h1 align="center">كاغويا البوت</h1>

<br><h4 align="center">تم تعديل بوت ماسنجر من قبل حسين يعقوبي كاغويا، ويُعد البوت أداة دردشة سهلة الاستخدام تهدف إلى تنشيط المجموعات. بالإضافة إلى ذلك، يقدم البوت مساعدة للطلاب وأعضاء المجموعة في مهامهم اليومية، مما يجعله مصدراً للترفيه والدراسة في نفس الوقت.</h4><br/>
#  ⚜️ كاغويا البوت 💟  </h1>

# ⚜️ بوت مسنجر دردشة
# ⚜️ بوت مسنجر الإصدار الأوال
# ⚜️ المالك : حسين يعقوبي 
# ⚜️ الأوامر تتم إضافتها بشكل مستمر
⚜️ رابط فيسبوك المطور :-https://www.facebook.com/profile.php?id=100076269693499)

# 🤝🏻 من أجل اي اسىئلة المرجو التواصل معي
<p align="center"> 
&nbsp; <a href="https://www.instagram.com/hussein_yacoubu/" target="_blank" rel="noopener noreferrer"><img src="https://img.icons8.com/plasticine/100/000000/instagram-new.png" width="100" /></a> 
&nbsp; <a href="https://www.tiktok.com/@darkomida2324?lang=en" target="_blank" rel="noopener noreferrer"><img src="https://i.imgur.com/jcWPUix.png" width="100" /></a>    
&nbsp; <a href="https://github.com/dashboard" target="_blank" rel="noopener noreferrer"><img src="https://img.icons8.com/plasticine/100/000000/github.png" width="100" /></a>
&nbsp; <a href="https://m.facebook.com/profile.php/?id=100076269693499" target="_blank" rel="noopener noreferrer"><img src="https://img.icons8.com/plasticine/100/000000/facebook.png"  width="100" /></a>
&nbsp; <a href="houssin.sb4@gmail.com" target="_blank" rel="noopener noreferrer"><img src="https://img.icons8.com/plasticine/100/000000/gmail.png"  width="100" /></a>
</p>
